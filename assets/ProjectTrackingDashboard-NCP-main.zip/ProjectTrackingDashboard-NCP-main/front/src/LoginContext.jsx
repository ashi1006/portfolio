// import React,{useState,createContext} from 'react';


// export const LoginContext =createContext();


// export const LogInProvider=(props)=>{
//     const [isLoggedIn,setLogin]=useState(false);

//     return (
//         <LoginContext.Provider>
//             {props.children}
//         </LoginContext.Provider>
//     );
// };